import { Component } from '@angular/core';

@Component({
  selector: 'app-mern',
  templateUrl: './mern.component.html',
  styleUrls: ['./mern.component.css']
})
export class MernComponent {

}
