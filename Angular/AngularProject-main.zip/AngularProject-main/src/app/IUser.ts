export interface IUser {
    id: Number;
    name: String;
    email: String;
    website: String;
phone: String;
address: any;
}