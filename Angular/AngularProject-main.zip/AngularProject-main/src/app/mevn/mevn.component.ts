import { Component } from '@angular/core';

@Component({
  selector: 'app-mevn',
  templateUrl: './mevn.component.html',
  styleUrls: ['./mevn.component.css']
})
export class MevnComponent {

}
